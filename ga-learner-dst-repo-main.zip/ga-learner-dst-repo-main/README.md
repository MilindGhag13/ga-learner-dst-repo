The GreyAtom Data Science Program takes you through the complete process of Data Science end-to-end right from the Python Programming Language to Machine Learning models - both foundational and advanced. There is a lot of hands-on learning happening through the projects that are an integral part of learning. All the concept projects are part of a single repository. The repository contains the different projects done as part of the following modules.

- Python Data Science Toolkit
- Foundations of Machine Learning
- Advanced Machine Learning
- Natural Language Processing